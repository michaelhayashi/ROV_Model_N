<NotepadPlus>
    <Session activeView="1">
        <mainView activeIndex="0" />
        <subView activeIndex="1">
            <File firstVisibleLine="0" xOffset="0" scrollWidth="672" startPos="122" endPos="122" selMode="0" lang="C" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\main.c" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="1496" startPos="122" endPos="122" selMode="0" lang="C++" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\functions.h" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="1688" startPos="9426" endPos="9426" selMode="0" lang="C" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\functions.c" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="496" startPos="79" endPos="79" selMode="0" lang="C++" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\buffer.h" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="488" startPos="19" endPos="19" selMode="0" lang="C" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\buffer.c" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="824" startPos="39" endPos="39" selMode="0" lang="C" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\usart.c" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="320" startPos="122" endPos="122" selMode="0" lang="C++" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\usart.h" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="847" startPos="487" endPos="487" selMode="0" lang="C" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\Libraries\STM32F4xx_StdPeriph_Driver\src\stm32f4xx_it.c" />
            <File firstVisibleLine="0" xOffset="0" scrollWidth="1127" startPos="245" endPos="245" selMode="0" lang="C++" encoding="-1" filename="C:\Users\Nick\Dropbox\ROV\abstract.h" />
        </subView>
    </Session>
</NotepadPlus>
